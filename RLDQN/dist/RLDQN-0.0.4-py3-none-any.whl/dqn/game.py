import gym
def make(name):
    return gym.make(name)