import setuptools

setuptools.setup(name='RLDQN',
      version='0.0.4',
      description='Asynchronous DQN',
      author='maigua',
      author_email='396032050@qq.com',
      license='MIT',
      packages=setuptools.find_packages())
